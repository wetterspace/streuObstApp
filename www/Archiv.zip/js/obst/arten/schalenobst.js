Obst.Arten.Schalenobst = [
	{
		Name: "Cashewnuss", 
		Latein: "Anacardium occidentale L."
	},
	{
		Name: "Coquito – Honigpalme", 
		Latein: "Jubaea chilensis"
	},
	{
		Name: "Erdnuss", 
		Latein: "Arachis hypogaea L."
	},
	{
		Name: "Edelkastanie", 
		Latein: "Castanea sativa MILL."
	},
	{
		Name: "Haselnuss", 
		Latein: "Corylus avellana L."
	},
	{
		Name: "Kemirinuss", 
		Latein: "Aleurites moluccana"
	},
	{
		Name: "Kokosnuss", 
		Latein: "Cocos nucifera L."
	},
	{
		Name: "Macadamia", 
		Latein: "Macadamia tetraphylla und Macadamia ternifolia"
	},
	{
		Name: "Mandel", 
		Latein: "Prunus dulcis"
	},
	{
		Name: "Paranuss", 
		Latein: "Bertholletia excelsa HUMB. & BONPL."
	},
	{
		Name: "Pecannuss", 
		Latein: "Carya illinoinensis"
	},
	{
		Name: "Pistazie", 
		Latein: "Pistacia vera L."
	},
	{
		Name: "Walnuss", 
		Latein: "Juglans regia L."
	}
];
