var currentWiese = null;


var init = function(){

	if(currentWiese == null){
		new Login();
	}

};